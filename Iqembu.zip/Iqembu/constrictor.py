#!/usr/bin/python

import subprocess
import os
import sys
import datetime

sourcepath='/bigdata/landing/sftp/'
targetpath='/bigdatahdfs/datalake/raw/'

def exist_error(message):
   sys.exit("ERROR: " + message)

def getFilesOnly(path):
    for file in os.listdir(path):
        if os.path.isfile(os.path.join(path, file)):
            yield file

def copyFile(linuxSource,hdfsTarget,overwrite):

 #Small file check
 linuxfilesize = int(os.path.getsize(linuxSource))

 if linuxfilesize < 134217728:
   #exist_error("Linux File '" + sys.argv[1] + "' to small. Must be at least 128MB")
   print("WARNING: Linux File '" + linuxSource + "' to small. Must be at least 128MB")

 #Check if file already exist on hdfs
 hdfsfilecheckcom = "hdfs dfs -test -e "+ hdfsTarget +";echo $?"
 hdfsfilecheck=subprocess.Popen(hdfsfilecheckcom,shell=True,stdout=subprocess.PIPE).communicate()

 if int(hdfsfilecheck[0]) == 0 and overwrite == 'no':
   print("ERROR: Hdfs file '" + hdfsTarget + "' already exists")
   return 123

 print("Copying file " + linuxSource + " to Hdfs path " + hdfsTarget)
 commandlist = ['hadoop','fs','-put','-f',linuxSource,hdfsTarget] # -f by this time its safe to overwrite file
 copyr=subprocess.call(commandlist)

 if int(copyr) == 0:
  print "Copying to HDFS - Done"
 else:
  exist_error("Error copying to HDFS")

 #Recon
 print "Start Recon"

 commandlist = ['hadoop','fs','-du','-s',hdfsTarget]
 hdfsfilesize = int(subprocess.Popen(commandlist,stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()[0].split()[0])
 linuxfilesize = int(os.path.getsize(linuxSource))

 if linuxfilesize == hdfsfilesize:
   print "Files match - now deleting linux file"
   os.remove(linuxSource)
 else:
   exist_error("Linux File '" + linuxSource + " and Hdfs file " + hdfsTarget + ' does not match in size')

def validate():

 parlen = len(sys.argv)

 usage = "\n" + sys.argv[0] + " <Your Linux Path> <Your HDFS (Hadoop) Path> Overwrite(yes or no Default no) Create Target Folder (yes or no Default no)\n" \
         "Example: " + sys.argv[0] + ' ' + sourcepath + "xxxx/file.txt " + targetpath + "xxxx yes yes"

 if parlen == 1:

  exist_error("Specify Linux Source File as first paramater: " + usage)

 elif parlen == 2:

  exist_error("Specify Hdfs Target Path as second paramater: " + usage)

 elif parlen == 3:

  sys.argv.append('no')

 elif parlen == 4:

  sys.argv.append('no')

 elif parlen == 5:

  #Kinit
  kinit = "kinit svc-datalake@CORP.DSARENA.COM -kt /home/svc-datalake/svc-datalake.keytab"
  subprocess.Popen(kinit,shell=True,stdout=subprocess.PIPE).communicate()

  #check source consistency
  if not sys.argv[1].startswith(sourcepath):
    exist_error("Linux File '" + sys.argv[1] + "' must be in " + sourcepath)

  #check overwrite
  if not (sys.argv[3] == "yes" or sys.argv[3] == "no"):
     exist_error("Overwrite parameter must be yes or no")

  #check prefixes
  if not os.path.exists(sys.argv[1]):
     exist_error("Linux File '" + sys.argv[1] + "' does not exist")

  #check target consistency
  if not sys.argv[2].startswith(targetpath):
    exist_error("Hdfs path '" + sys.argv[2] + "' must be in " + targetpath)

  #Check if source path has a source folder
  filename=os.path.basename(sys.argv[1])
  sourcesystem = sys.argv[1].replace(sourcepath,'').replace(filename,'').replace('/','')
  if sourcesystem == '':
     exist_error("Linux File '" + sys.argv[1] + "' does not contain a source system folder")

  #Check source and target source system
  if not sourcesystem in sys.argv[2]:
    exist_error("Source System (" + sourcesystem + ") must match in source and target")

  #Check if HDFS Directory exist
  hdfsdircheckcom = "hdfs dfs -test -d "+sys.argv[2]+";echo $?"
  hdfsdircheck=subprocess.Popen(hdfsdircheckcom,shell=True,stdout=subprocess.PIPE).communicate()

  if int(hdfsdircheck[0]) == 1: #Target Directory does not exist on hadoop

    if sys.argv[4] == 'yes':
      print("Creating target folder : " + sys.argv[2])
      commandlist = ['hadoop','fs','-mkdir','-p',sys.argv[2]]
      mkdirr=subprocess.call(commandlist)

      if int(mkdirr) == 0:
            print "Target Folder created"
      else:
            exist_error("Error Target Folder")

    else:
      exist_error("Hdfs path '" + sys.argv[2] + "' either does not exist or is a file. Must be a valid Hdfs path only.")

def is7zZip(file):
  with open(file, 'rb') as fd:
    file_head = fd.read(2)

  return file_head == '7z'

def processFile(source,target,overwrite):

  if is7zZip(source):

   print("Found 7 zip file - Extracting...")
   fp = source + 'UZ'
   dontclean = False

   com='7za -y e '+ source + ' -o' + fp
   subprocess.Popen(com,shell=True,stdout=subprocess.PIPE).communicate()

   for f in getFilesOnly(fp):
     r = copyFile(fp + '/' + f,target + '/' + f,overwrite)
     if r == 123:
         dontclean = True

   #clean up
   cleanup ='rm -r ' + fp
   print "Cleaning up tmp folder (" + fp + ")"
   subprocess.Popen(cleanup,shell=True,stdout=subprocess.PIPE).communicate()

   if not dontclean:
     cleanup ='rm -r ' + source
     print "Deleting 7zip file (" + source + ")"
     subprocess.Popen(cleanup,shell=True,stdout=subprocess.PIPE).communicate()

  else:
    filename=os.path.basename(sys.argv[1])
    copyFile(source,target + '/' + filename,overwrite)

def main():

 #start checks
 validate()

 #passed all checks now start precedings
 processFile(sys.argv[1],sys.argv[2],sys.argv[3])

if __name__== "__main__":
  main()
