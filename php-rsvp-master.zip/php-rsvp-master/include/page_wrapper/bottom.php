</body>

</html>
<?php
    if (isset($rsvp_conn)) {
        $rsvp_conn->close();
    }
?>
