#!/bin/bash
# MySQL User
USER='root'
# MySQL Password
PASSWORD='Abs@hdpmysql'
OUTPUT="/hadoop/mysqlbackup"
                echo $time
                TIMESTAMP=`date +%Y%m%d_%H%M%S`;
                mkdir $OUTPUT/bckdir_$TIMESTAMP;
                cd $OUTPUT/bckdir_$TIMESTAMP;
                echo "Starting MySQL Backup";
                echo `date`;
                databases=`mysql -h jhbpsr020000102.intranet.barcapint.com   --user=$USER --password=$PASSWORD  -e "SHOW DATABASES;" | tr -d "| " | grep -v Database`
                for db in $databases; do
                        echo "db  :$db"
                        if [[ "$db" != "information_schema" ]] && [[ "$db" != _* ]] && [[ "$db" != "performance_schema" ]] ; then
                                echo "Dumping database: $db"
                                mysqldump -h jhbpsr020000102.intranet.barcapint.com  --user=$USER --password=$PASSWORD --databases $db > $OUTPUT/bckdir_$TIMESTAMP/dbbackup-$TIMESTAMP-$db.sql
                                gzip $OUTPUT/bckdir_$TIMESTAMP/dbbackup-$TIMESTAMP-$db.sql
                        fi
                done
        echo "Finished MySQL Backup";
        echo `date`
sleep 60

# Delete Directories older than 7 days
echo " Delete old backups"
find $OUTPUT* -name "bckdir*" -mtime +7 -exec rm -rf {} \;

#ssh ambari-qa@jhbpsr020000101 mkdir -p $OUTPUT/bckdir_$TIMESTAMP;
scp -r $OUTPUT/bckdir_$TIMESTAMP  ambari-qa@jhbpsr020000101:$OUTPUT/bckdir_$TIMESTAMP

#kinit ambari-qa -kt /home/ambari-qa/ambari-qa.keytab
kinit syshdfsgala -kt /etc/security/keytabs/hdfs.headless.keytab
echo "Copy to Hadoop Directories"
hadoop fs -put $OUTPUT/bckdir_$TIMESTAMP /MARIADBBACKUP
#Delete old  Hadoop Backups
echo "De;ete Old Directories"
sdays=7
now=$(date +%s)
hadoop fs -ls  -R /MARIADBBACKUP | grep "^d" | while read f; do
  dir_date=`echo $f | awk '{print $6}'`
  difference=$(( ( $now - $(date -d "$dir_date" +%s) ) / (24 * 60 * 60 ) ))
  if [ $difference -gt $sdays ]; then
    hadoop fs -rm -r $f;
  fi
done
