
#!/usr/bin/env python

import sys
import subprocess
import datetime

msg = "number of args must be 3 , source system {0}, batch id {1} and usergroup {2}"

if len(sys.argv) <= 3:
 print msg
 exit()

source = sys.argv[1]
batchuser = sys.argv[2]
usergroup = sys.argv[3]
owner = batchuser + ':' + usergroup
print (owner)

landing_dir ="/bigdatahdfs/landing/" + source
publish_dir ="/bigdatahdfs/datalake/publish/" + source
raw_dir ="/bigdatahdfs/datalake/raw/" + source
hdfs_home = "/user/" + batchuser
print "*************************************"


def run_cmd(args_list):
        """
        run linux commands
        """
        # import subprocess
        print('Running system command: {0}'.format(' '.join(args_list)))
        proc = subprocess.Popen(args_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        s_output, s_err = proc.communicate()
        s_return =  proc.returncode
        return s_return, s_output, s_err


(ret, out, err)= run_cmd(['kinit', 'syshdfsjedi', '-kt', '/etc/security/keytabs/hdfs.headless.keytab'])
print "-----------------------------------------------------"
print ("Creating home directory in %s:" % hdfs_home)
(ret, out, err)= run_cmd(['hdfs', 'dfs', '-mkdir', '-p', hdfs_home ])
print ("Creating directory in %s:" % landing_dir)
(ret, out, err)= run_cmd(['hdfs', 'dfs', '-mkdir', '-p', landing_dir ])
print ("Creating directory in %s:" % publish_dir)
(ret, out, err)= run_cmd(['hdfs', 'dfs', '-mkdir', '-p', publish_dir ])
print ("Creating directory in %s:" % raw_dir)
(ret, out, err)= run_cmd(['hdfs', 'dfs', '-mkdir', '-p', raw_dir ])

print "-----------------------------------------------------"
print ("Changing permissions of directory in %s:" % landing_dir)
(ret, out, err)= run_cmd(['hdfs', 'dfs', '-chown', '-R', owner , landing_dir ])
print ("Changing permissions of directory in %s:" % publish_dir)
(ret, out, err)= run_cmd(['hdfs', 'dfs', '-chown', '-R', owner , publish_dir ])
print ("Changing permissions of directory in %s:" % raw_dir)
(ret, out, err)= run_cmd(['hdfs', 'dfs', '-chown', '-R', owner , raw_dir ])

print "-----------------------------------------------------"
print ("Changing ownership of directory in %s:" % landing_dir)
(ret, out, err)= run_cmd(['hdfs', 'dfs', '-chmod', '-R', '750' , landing_dir ])
print ("Changing ownership of directory in %s:" % publish_dir)
(ret, out, err)= run_cmd(['hdfs', 'dfs', '-chmod', '-R', '750' , publish_dir ])
print ("Changing ownership of directory in %s:" % raw_dir)
(ret, out, err)= run_cmd(['hdfs', 'dfs', '-chmod', '-R', '750' , raw_dir ])



===============================================================================================================


