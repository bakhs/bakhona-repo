#!/bin/sh
export SPARK_MAJOR_VERSION=2
kinit sysafhprzapock -kt ~/sysafhprzapock.keytab
cd /bigdata/project/pock/app

PF_SPARK_OPTIONS="--master yarn --deploy-mode client --driver-memory 3G --executor-memory 5G --verbose --num-executors 10 --conf spark.jars.ivySettings=ivysettings.xml --conf spark.yarn.executor.memoryOverhead=4096 --conf spark.driver.extraJavaOptions=-Djava.security.auth.login.config=client_jaas.conf --conf spark.executor.extraJavaOptions=-Djava.security.auth.login.config=client_jaas.conf --repositories http://nexus.absa.co.za:8081/repository/releases/,http://nexus.absa.co.za:8081/repository/Maven2  --packages com.absa:PocketFlow:1.0.8 --files pocketflow.properties#pocketflow.properties,log4j.properties,client_jaas.conf,client.truststore.jks"

echo "$PF_SPARK_OPTIONS"
PF_EMPTY_JAR_FILE="empty_jar_file.jar"
PFTask="$1"
#shift is used to remove the first argument
shift

if [ "$PFTask" == "AllSummaries" ];then
        spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.AllSummaries $PF_EMPTY_JAR_FILE "$@" --summariesToExclude SpendByCardScheme$,NewAndReturningCustomers$,SpendByIncomeGroup$
elif [ "$PFTask" == "LongRunningSummaries" ]; then
        spark-submit ${PF_SPARK_OPTIONS} --conf spark.sql.broadcastTimeout=900 --class abcap.pocketflo.spark.drivers.AllSummaries $PF_EMPTY_JAR_FILE "$@" --summariesToInclude NewAndReturningCustomers$
        spark-submit ${PF_SPARK_OPTIONS} --conf spark.sql.broadcastTimeout=900 --class abcap.pocketflo.spark.drivers.AllSummaries $PF_EMPTY_JAR_FILE "$@" --summariesToInclude SpendByCardScheme$
        spark-submit ${PF_SPARK_OPTIONS} --conf spark.sql.broadcastTimeout=900 --class abcap.pocketflo.spark.drivers.AllSummaries $PF_EMPTY_JAR_FILE "$@" --summariesToInclude SpendByIncomeGroup$
elif [ "$PFTask" == "WeeklyFetchEDWData" ]; then
        spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.WeeklyFetchEDWData $PF_EMPTY_JAR_FILE "$@"
elif [ "$PFTask" == "DailyImportCardInterchangeTransactions" ]; then
        spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.daily.DailyImportCardInterchangeTransactions $PF_EMPTY_JAR_FILE "$@"
elif [ "$PFTask" == "ManualCatchupFetchEDWCardData" ]; then
# run each month separately to avoid long-running jobs that stall
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2015-12-01 2016-01-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2016-01-01 2016-02-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2016-02-01 2016-03-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2016-03-01 2016-04-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2016-04-01 2016-05-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2016-05-01 2016-06-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2016-06-01 2016-07-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2016-07-01 2016-08-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2016-08-01 2016-09-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2016-09-01 2016-10-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2016-10-01 2016-11-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2016-11-01 2016-12-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2016-12-01 2017-01-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2017-01-01 2017-02-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2017-02-01 2017-03-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2017-03-01 2017-04-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2017-04-01 2017-05-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2017-05-01 2017-06-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2017-06-01 2017-07-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2017-07-01 2017-08-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2017-08-01 2017-09-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2017-09-01 2017-10-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2017-10-01 2017-11-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2017-11-01 2017-12-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2017-12-01 2018-01-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2018-01-01 2018-02-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2018-02-01 2018-03-01
        #spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2018-03-01 2018-04-01
        spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.edw.weekly.ManualCatchupFetchEDWCardData $PF_EMPTY_JAR_FILE 2018-04-01 2018-05-01
elif [ "$PFTask" == "Weekly_ETL_EDW_and_lookup_tables" ]; then
  spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.weekly.Weekly_ETL_EDW_and_lookup_tables $PF_EMPTY_JAR_FILE "$@"
elif [ "$PFTask" == "DailyIssuerImport" ]; then
  spark-submit ${PF_SPARK_OPTIONS} --class abcap.pocketflo.spark.drivers.etl.issuer.IssuerDailyImport $PF_EMPTY_JAR_FILE "$@"
else
echo "unknown parameter"
exit 1
fi
echo "Pocketflow script complete"
exit 0