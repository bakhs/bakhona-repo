select CAST(p42_card_accpt_id AS INT) MerchantNumber
                  ,CAST(head_term_id AS INT) TerminalDeviceId
                  ,card_number
                  ,tran_date
                  ,tran_type
                  ,processing_status 
                  ,line_item_detail
      ,substring(line_item_detail,1,6) ResponseCode
                  ,substring(line_item_detail,7,3) RecordTypeCode
      ,substring(line_item_detail,10,5) TransactionCode
      ,substring(line_item_detail,15,3) BalanceFeeCode
      ,substring(line_item_detail,18,13) BalanceFee
                  ,BIN10 Issues_BIN
                  ,MAX(effective_date)
from aps_card_everest
WHERE tran_type in ('17','31')
  AND substring(line_item_detail,1,6) <> '      '
  AND PROCESSING_STATUS like "%TRS%"
  GROUP by p42_card_accpt_id,head_term_id,card_number,tran_date,tran_type,processing_status,line_item_detail,BIN10
  
  
  
  
  
  
  
  
  
  

gadesudh,fGLBpbservPRPRLMPP
lemark1,fGLBpbservPRPRLMPP
mareema,fGLBpbservPRPRLMPP
meiernic,fGLBpbservPRPRLMPP